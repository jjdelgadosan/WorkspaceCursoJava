package bean;

public class Programador extends Empleado {

	@Override
	public  double calculaSueldo() {
		
		
		
	 return this.getSueldoBase();
		
	}

}
